Sensible WP

===

a WordPress theme for almost anything. 

Sensible, Copyright 2015 ModernThemes
Sensible is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

This theme, like WordPress, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.

Sensible is built with Underscores http://underscores.me/, (C) 2012-2014 Automattic, Inc.

Sensible incorporates code from Moesia, Copyright 2014 aThemes
Moesia is distributed under the terms of the GNU GPL  

Sensible bundles the following third-party resources:

Simple Grid by ThisisDallas Copyright (C) 2013 Dallas Bass
Simple Grid is licensed under the MIT License.
http://thisisdallas.github.io/Simple-Grid/

Custom Meta Boxes by WebDevStudio (c) 2014 WebDevStudio 
Custom Meta Boxes is licensed under the terms of the GNU GPLv2 
https://github.com/WebDevStudios/Custom-Metaboxes-and-Fields-for-WordPress

Font Awesome by Dave Gandy
Font Awesome is licensed under the following: (Font: SIL OFL 1.1, CSS: MIT License)
http://fortawesome.github.io/Font-Awesome/

Parallax.js by PixelCog Inc. (c) 2015 PixelCog Inc.
Parallax.js is distributed under the The MIT License (MIT).
https://github.com/pixelcog/parallax.js

wow.js by Matthieu Aussaguel Copyright (C) 2014; 
wow.js is is distributed under the The MIT License (MIT).
https://github.com/matthieua/WOW

The HTML5 Shiv by aFarkas Copyright (c) 2014 Alexander Farkas (aFarkas).
The HTML5 Shiv is licensed under the terms of the GNU GPLv2 
https://github.com/aFarkas/html5shiv 

jPushMenu by takien
jPushMenu is licensed under the terms of the GNU GPLv2 
https://github.com/takien/jPushMenu

all free stock photos including homepage backgrounds and image used in screenshot provided by Unsplash at https://unsplash.com/

Resetting and rebuilding styles have been helped along thanks to the fine work of
Eric Meyer http://meyerweb.com/eric/tools/css/reset/index.html
along with Nicolas Gallagher and Jonathan Neal http://necolas.github.com/normalize.css/
and Blueprint http://www.blueprintcss.org/ 

Sensible is a multi-purpose theme which can be used for any type of website. It is a flexbible theme which can be used to help build an online presence with attractive features. I mean, when we made this theme, we had everyone in mind. No matter what kind of site you have, you can use this theme. Business? No problem. Agency? Knock yourself out. Just trying to get some blogs going? This theme is perfect for it. This theme is completely customizable through the Wordpress Theme Customizer. You can check the demo at http://modernthemes.net/demo/sensiblewp.

all theme documentation can be found at http://modernthemes.net/documentation/sensible-documentation/